
public class Squirrel extends Animal {
	 public Squirrel()
	    {
	    	this.name = "Squirrel";
	    	this.age = 3;
	    	this.classification = "Rodent";
	    }

	    public void display()
	    {
	       System.out.println("There is a Squirrrel here and it Scurries");
	    }
}
