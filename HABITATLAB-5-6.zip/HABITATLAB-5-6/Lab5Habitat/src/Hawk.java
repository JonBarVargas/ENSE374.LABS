
public class Hawk extends Animal{
	 public Hawk()
	    {
	    	this.name = "Hawk";
	    	this.age = 5;
	    	this.classification = "Bird";
	    }

	    public void display()
	    {
	    	System.out.println("There is a Hawk here and it soars");
	    }
}

