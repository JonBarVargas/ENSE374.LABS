
public class Organism {
public void display() {
}
}
