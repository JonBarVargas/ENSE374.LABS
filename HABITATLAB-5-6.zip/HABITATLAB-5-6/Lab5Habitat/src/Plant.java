
public class Plant extends Organism{
    public String name;
    public int age;
    
    public Plant() {
    	this.name = "";
    	this.age = 0;
    }
}
