
public class Animal extends Organism {
    public String name;
    public int age;
    public String classification;
    
    public Animal() {
    	   this.name = "";
    	   this.age = 0;
    	   this.classification = "";
    }
    
 public void eat() 
 {
 }
 public void move()
 {
 }
 
}
