
public class Wolf extends Animal{
    public Wolf()
    {
    	this.name = "Wolf";
    	this.age = 5;
    	this.classification = "Mammal";
    }

    public void display()
    {
    	System.out.println("There is a wolf here and it howls");
    }
}
