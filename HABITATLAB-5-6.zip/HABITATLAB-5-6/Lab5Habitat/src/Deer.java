
public class Deer extends Animal{ 
	public Deer()
	    {
	    	this.name = "Deer";
	    	this.age = 5;
	    	this.classification = "Mammal";
	    }

	    public void display()
	    {
	    	 System.out.println("There is a Deer here and it prances");
	    }
	    
}
